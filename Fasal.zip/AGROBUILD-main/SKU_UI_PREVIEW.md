# SKU Variant System - UI Preview

## Create/Edit Product Page Layout

```
┌─────────────────────────────────────────────────────────────────┐
│                        Create Product                           │
└─────────────────────────────────────────────────────────────────┘

[Image Upload Section]
[Product Name Input]
[Category Dropdown]
[Subcategory Dropdown]
[MRP & Price Inputs]
[SKU & Brand Inputs]
[Stock Quantity Input]
[Description Textarea]

┌─────────────────────────────────────────────────────────────────┐
│                      SKU Variants *                             │
│                                                                 │
│ Add product variants with different units, quantities,         │
│ and box packing options                                        │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│ Added Variants (3)                                              │
│                                                                 │
│ ┌──────────────────────────────┐  ┌──────────────────────────┐ │
│ │ 100 ml (Litre)          [🗑]  │  │ 250 ml (Litre)      [🗑] │ │
│ │ 6 pieces per box              │  │ 6 pieces per box        │ │
│ ├──────────────────────────────┤  ├──────────────────────────┤ │
│ │ Unit Price: ₹50               │  │ Unit Price: ₹125        │ │
│ │ Unit MRP: ₹75                 │  │ Unit MRP: ₹187.50       │ │
│ │                               │  │                          │ │
│ │ Box Total: ₹300 for 6 units   │  │ Box Total: ₹750         │ │
│ │ Box Price: ₹300 │ Box MRP: ₹450
│ │ Box Price: ₹750 │ Box MRP: ₹1,125
│ └──────────────────────────────┘  └──────────────────────────┘ │
│                                                                 │
│ ┌──────────────────────────────┐                               │
│ │ 500 ml (Litre)          [🗑]  │                               │
│ │ 6 pieces per box              │                               │
│ ├──────────────────────────────┤                               │
│ │ Unit Price: ₹250              │                               │
│ │ Unit MRP: ₹375                │                               │
│ │                               │                               │
│ │ Box Total: ₹1,500             │                               │
│ │ Box Price: ₹1,500 │ MRP: ₹2,250
│ └──────────────────────────────┘                               │
│                                                                 │
│ ┌─────────────────────────────────────────────────────────────┐│
│ │ [+ Add SKU Variant]                                         ││
│ └─────────────────────────────────────────────────────────────┘│
│                                                                 │
└─────────────────────────────────────────────────────────────────┘

[Create Product Button] [Cancel Button]
```

## Add SKU Variant Form (Expanded)

```
┌──────────────────────────────────────────────────────────┐
│            Add New Variant                                │
├──────────────────────────────────────────────────────────┤
│                                                           │
│ Unit Type *              │ Quantity *                     │
│ ┌─────────────────────┐  │ ┌──────────────────────────┐  │
│ │ Select Unit Type ▼  │  │ │ Select Quantity ▼        │  │
│ │ - Litre (L)         │  │ │ (Options appear when     │  │
│ │ - Kilogram (Kg)     │  │ │  unit type selected)     │  │
│ └─────────────────────┘  │ └──────────────────────────┘  │
│                          │                                │
│ Unit Price (₹) *    │ Unit MRP (₹) * │ Pieces per Box * │
│ ┌──────────────────┐ │ ┌──────────────┐ │ ┌────────────┐ │
│ │ e.g., 150        │ │ │ e.g., 200    │ │ │ 6 pieces ▼ │ │
│ │ [__________]     │ │ │ [__________] │ │ │ - 6        │ │
│ └──────────────────┘ │ └──────────────┘ │ │ - 8        │ │
│                      │                   │ │ - 10       │ │
│ ┌────────────────────────────────────┐  │ │ - 12       │ │
│ │ ✨ Box Calculation Preview:        │  │ └────────────┘ │
│ │ Box Calculation: 6 units × ₹150    │  │                │
│ │ = ₹900                             │  │                │
│ │                                    │  │                │
│ │ Box MRP: 6 units × ₹200            │  │                │
│ │ = ₹1,200                           │  │                │
│ └────────────────────────────────────┘  │                │
│                                          │                │
│ [✓ Add Variant] [Cancel]                                 │
│                                                           │
└──────────────────────────────────────────────────────────┘
```

## Unit Type Selection

### When "Litre" is Selected:
```
Quantity Dropdown Options:
- 100 ml
- 250 ml
- 500 ml
- 1 Litre
```

### When "Kg" is Selected:
```
Quantity Dropdown Options:
- 100 g
- 250 g
- 500 g
- 1 Kg
```

## Box Quantity Selection
```
Fixed Options:
- 6 pieces
- 8 pieces
- 10 pieces
- 12 pieces
```

## Real-World Example: Cooking Oil Product

```
Create Product: Premium Cooking Oil
MRP: ₹250/Litre
Price: ₹200/Litre

┌──────────────────────────────────────┐
│  Added Variants (4)                  │
│                                      │
│  250ml × 6 → ₹300 | MRP ₹450        │
│  500ml × 6 → ₹600 | MRP ₹900        │
│  1L × 6    → ₹1200 | MRP ₹1500      │
│  1L × 12   → ₹2400 | MRP ₹3000      │
│                                      │
│  [+ Add SKU Variant]                 │
│  [✓ Create Product] [Cancel]         │
└──────────────────────────────────────┘
```

## Responsive Layout (Mobile)

```
┌─────────────────────────┐
│   Create Product        │
├─────────────────────────┤
│ [Upload Images]         │
│ [Product Name]          │
│ [Category]              │
│ [Subcategory]           │
│ [MRP] [Price]           │
│ [SKU] [Brand]           │
│ [Stock Qty]             │
│ [Description]           │
│                         │
│ ┌───────────────────────┤
│ │ SKU Variants          │
│ ├───────────────────────┤
│ │ 100ml × 6             │
│ │ ₹300 | MRP ₹450       │ [X]
│ ├───────────────────────┤
│ │ 250ml × 6             │
│ │ ₹750 | MRP ₹1,125     │ [X]
│ └───────────────────────┘
│                         │
│ [+ Add Variant]         │
│                         │
│ [Create] [Cancel]       │
└─────────────────────────┘
```

## Variant Card States

### Default State (Collapsed)
```
┌────────────────────────────────┐
│ 250 ml (Litre)          [Delete]│
│ 6 pieces per box               │
├────────────────────────────────┤
│ Unit Price: ₹125               │
│ Unit MRP: ₹187.50              │
│ Box Price: ₹750 | MRP: ₹1,125  │
└────────────────────────────────┘
```

### Hover State
```
┌────────────────────────────────┐
│ 250 ml (Litre)          [🗑︎ Delete] ← Visible on hover
│ 6 pieces per box               │
├────────────────────────────────┤
│ Unit Price: ₹125               │
│ Unit MRP: ₹187.50              │
│ Box Price: ₹750 | MRP: ₹1,125  │
└────────────────────────────────┘
```

## Form Validation States

### All Fields Filled ✓
```
┌─────────────────────────────────┐
│ Unit Type: Litre (filled) ✓     │
│ Quantity: 500ml (filled) ✓      │
│ Unit Price: ₹250 (filled) ✓     │
│ Unit MRP: ₹375 (filled) ✓       │
│ Box Qty: 6 (filled) ✓           │
├─────────────────────────────────┤
│ ✨ Preview:                     │
│ Box: ₹250 × 6 = ₹1,500          │
│ MRP: ₹375 × 6 = ₹2,250          │
│                                 │
│ [✓ Add Variant] [Cancel]        │
│   (Button enabled)              │
└─────────────────────────────────┘
```

### Missing Fields ✗
```
┌─────────────────────────────────┐
│ Unit Type: [empty] ✗            │
│ Quantity: [empty] ✗             │
│ Unit Price: 250 ✓               │
│ Unit MRP: [empty] ✗             │
│ Box Qty: 6 ✓                    │
├─────────────────────────────────┤
│ Preview: (not shown)            │
│                                 │
│ [✓ Add Variant] [Cancel]        │
│   (Button disabled)             │
│   "Please fill all fields"      │
└─────────────────────────────────┘
```

## Success Messages

### After Adding Variant
```
┌─────────────────────────────────┐
│ ✓ Variant added successfully    │
│                                 │
│ [Close or auto-hide in 3s]      │
└─────────────────────────────────┘
```

### After Creating Product
```
┌─────────────────────────────────┐
│ ✓ Product created successfully  │
│                                 │
│ Redirecting to /admin/products  │
└─────────────────────────────────┘
```

## Error States

### Missing SKU Variants
```
Product Creation Form
[All fields filled]

[✓ Create Product] ← Disabled (Red)
└─ "Please add at least one SKU variant"
```

### Validation Error
```
┌──────────────────────────────┐
│ ✗ Please fill all variant    │
│   fields                     │
│                              │
│ [OK]                         │
└──────────────────────────────┘
```

---

## Color Scheme

| Element | Color | Purpose |
|---------|-------|---------|
| Header | Emerald-500 | Primary branding |
| Card Background | White | Clean display |
| Section Border | Blue-200 | Section grouping |
| Section BG | Blue-50 | Light highlight |
| Preview BG | Blue-100 | Calculation highlight |
| Button Primary | Green-600 | Action positive |
| Button Danger | Red-500 | Delete action |
| Text Primary | Gray-900 | Main text |
| Text Secondary | Gray-600 | Labels |
| Success | Green-600 | Success messages |
| Error | Red-600 | Error messages |

---

## Keyboard Navigation

- Tab: Navigate between fields
- Enter: Submit form / Add variant
- Escape: Close form / Cancel
- Delete/Backspace: Works on selected input

---

## Accessibility Features

- ✓ Labels for all inputs
- ✓ ARIA descriptions for complex elements
- ✓ Keyboard navigation support
- ✓ Focus states visible
- ✓ Error messages clear
- ✓ Color not only indicator
- ✓ Button text descriptive
