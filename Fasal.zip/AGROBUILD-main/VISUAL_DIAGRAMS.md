# 📊 VISUAL DIAGRAMS & FLOWCHARTS

## 1. System Architecture Diagram

```
┌──────────────────────────────────────────────────────────┐
│                   AGROBUILD SYSTEM                       │
└──────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────┐
│              Frontend Layer (React)                      │
├─────────────────────────────────────────────────────────┤
│                                                          │
│  AdminCreateProduct.tsx                                 │
│  ├─ Product Form                                        │
│  │  ├─ product_id, title, price, mrp                   │
│  │  ├─ category, brand, stock                          │
│  │  └─ description, features, technical info           │
│  ├─ Image Upload                                        │
│  │  ├─ Upload to Supabase Storage                       │
│  │  ├─ Get public URLs                                  │
│  │  └─ Store in images array                            │
│  └─ SKU Management                                      │
│     ├─ Add Variant Button                               │
│     ├─ Unit Type (Litre/Kg)                             │
│     ├─ Quantity (500ml, 1L, etc)                        │
│     ├─ Pieces per Box (6, 8, 10, 12)                    │
│     ├─ Unit & Box Pricing                               │
│     └─ Delete Variant Button                            │
│                                                          │
└────────────────────┬────────────────────────────────────┘
                     │
                     │ POST /api/admin/products
                     │ {
                     │   product fields,
                     │   images: [url1, url2],
                     │   sku_variants: [{...}]
                     │ }
                     │
                     ▼
┌─────────────────────────────────────────────────────────┐
│              API Layer (Express.js)                      │
├─────────────────────────────────────────────────────────┤
│                                                          │
│  server/routes/admin/products.ts                        │
│  POST /api/admin/products                               │
│  PUT /api/admin/products/:id                            │
│  DELETE /api/admin/products/:id                         │
│                                                          │
│  server/routes/products.ts                              │
│  GET /api/products (with skus)                          │
│  GET /api/products/:id (with skus)                      │
│  GET /api/products/by-product-id/:id (with skus)        │
│                                                          │
└────────────────────┬────────────────────────────────────┘
                     │
                     │ Calls admin functions
                     ▼
┌─────────────────────────────────────────────────────────┐
│          Database Layer (server/lib/db/admin.ts)        │
├─────────────────────────────────────────────────────────┤
│                                                          │
│  adminCreateProduct(payload)                            │
│  ├─ Extract sku_variants                                │
│  ├─ Insert product → products table                     │
│  ├─ Get returned product.id                             │
│  └─ Insert skus → product_skus table                    │
│                                                          │
│  adminUpdateProduct(id, payload)                        │
│  ├─ Update product → products table                     │
│  ├─ Delete old skus                                     │
│  └─ Insert new skus → product_skus table                │
│                                                          │
│  adminDeleteProduct(id)                                 │
│  └─ Delete product (cascade → deletes skus)             │
│                                                          │
└────────────────────┬────────────────────────────────────┘
                     │
                     │ Supabase Client
                     ▼
┌─────────────────────────────────────────────────────────┐
│         PostgreSQL Database (Supabase)                   │
├─────────────────────────────────────────────────────────┤
│                                                          │
│  ┌──────────────────────────┐                           │
│  │     PRODUCTS TABLE       │                           │
│  ├──────────────────────────┤                           │
│  │ id (PK)                  │                           │
│  │ product_id (UNIQUE)      │                           │
│  │ title                    │                           │
│  │ price, mrp, discount     │                           │
│  │ category_name            │                           │
│  │ brand, description       │                           │
│  │ images (TEXT[])          │◄────┐                     │
│  │ image_count (INT)        │     │ Auto-managed        │
│  │ primary_image (TEXT)     │     │ by trigger          │
│  │ stock_quantity           │◄────┘                     │
│  │ gst_percentage           │                           │
│  │ availability             │                           │
│  │ created_at               │                           │
│  └────────────┬─────────────┘                           │
│               │ FK (id)                                 │
│               │ ON DELETE CASCADE                       │
│               │                                         │
│               ▼                                         │
│  ┌──────────────────────────┐                           │
│  │  PRODUCT_SKUS TABLE      │                           │
│  ├──────────────────────────┤                           │
│  │ id (PK)                  │                           │
│  │ product_id (FK)          │                           │
│  │ unit_type (CHK)          │ ('Litre' or 'Kg')         │
│  │ quantity (VARCHAR)       │ ('500ml', '1L', etc)      │
│  │ pieces_per_box (CHK)     │ (6, 8, 10, 12)            │
│  │ unit_price               │                           │
│  │ unit_mrp                 │                           │
│  │ box_price                │                           │
│  │ box_mrp                  │                           │
│  │ created_at, updated_at   │                           │
│  └──────────────────────────┘                           │
│                                                          │
│  Trigger: update_product_image_count()                  │
│  ├─ Fires BEFORE INSERT/UPDATE of images               │
│  ├─ Calculates image_count from array length            │
│  └─ Sets primary_image to first array element           │
│                                                          │
│  Indexes:                                               │
│  ├─ idx_products_images (GIN on images)                 │
│  ├─ idx_product_skus_product_id                         │
│  └─ idx_product_skus_unit_type                          │
│                                                          │
└─────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────┐
│              Storage Layer (Supabase Storage)            │
├─────────────────────────────────────────────────────────┤
│                                                          │
│  Bucket: "products"                                     │
│  ├─ product1/image1.jpg                                 │
│  ├─ product1/image2.jpg                                 │
│  ├─ product2/image1.jpg                                 │
│  └─ etc...                                              │
│                                                          │
│  Returns public URLs stored in images array             │
│                                                          │
└─────────────────────────────────────────────────────────┘
```

---

## 2. Product Creation Flow

```
START
  │
  ▼
┌─────────────────────────────────────┐
│ User opens Admin Create Product     │
└──────────────┬──────────────────────┘
               │
               ▼
┌─────────────────────────────────────┐
│ Fill Product Basic Info             │
│ - product_id                        │
│ - title                             │
│ - price, mrp                        │
│ - category_name                     │
│ - stock_quantity                    │
│ - Other fields...                   │
└──────────────┬──────────────────────┘
               │
               ▼
┌─────────────────────────────────────┐
│ Upload Images                       │
│ - Browse files                      │
│ - Upload to Supabase Storage        │
│ - Get public URLs                   │
│ - Add to images array: [url1, url2] │
└──────────────┬──────────────────────┘
               │
               ▼
┌─────────────────────────────────────┐
│ Add SKU Variants (Optional)         │
│ ┌─────────────────────────────────┐ │
│ │ Click "Add SKU Variant"         │ │
│ ├─────────────────────────────────┤ │
│ │ Unit Type: [Litre ▼] or [Kg ▼] │ │
│ │ Quantity: [500ml ▼]             │ │
│ │ Pieces/Box: [6 ▼]               │ │
│ │ Unit Price: [150]               │ │
│ │ Unit MRP: [200]                 │ │
│ │ Box Price: [auto: 900]          │ │
│ │ Box MRP: [auto: 1200]           │ │
│ │                                 │ │
│ │ [Add Variant] [Delete]          │ │
│ └─────────────────────────────────┘ │
│ Add multiple variants (repeat)      │
└──────────────┬──────────────────────┘
               │
               ▼
┌─────────────────────────────────────┐
│ Validate Form                       │
│ ✓ Required fields filled            │
│ ✓ Images array not empty            │
│ ✓ SKU constraints (if provided)     │
└──────────────┬──────────────────────┘
               │
        ┌──────┴──────┐
        │             │
        ▼             ▼
    ❌ INVALID    ✅ VALID
        │             │
        ▼             ▼
    Show Error    Prepare Payload
                      │
                      ▼
                ┌─────────────────────┐
                │ Create Payload:     │
                │ {                   │
                │  product_id: "...", │
                │  title: "...",      │
                │  price: 200,        │
                │  images: [url1,...],│
                │  sku_variants: [    │
                │    {                │
                │     unitType:"L",   │
                │     quantity:"500ml",
                │     piecesPerBox:6, │
                │     price:150,      │
                │     mrp:200,        │
                │     boxPrice:900,   │
                │     boxMrp:1200     │
                │    },               │
                │    {...more...}     │
                │  ]                  │
                │ }                   │
                └──────────┬──────────┘
                           │
                           ▼
                ┌──────────────────────┐
                │ POST /api/admin/products
                │ Content-Type: application/json
                └──────────────┬───────┘
                               │
                               ▼ (Network)
                ┌──────────────────────────────┐
                │ adminCreateProduct(payload)  │
                └──────────────┬───────────────┘
                               │
                    ┌──────────┴──────────┐
                    ▼                     ▼
            Separate payload      Map SKU fields
            Extract sku_variants  unitType→unit_type
            Rest → productData    piecesPerBox→pieces_per_box
                    │                     │
                    └──────────┬──────────┘
                               │
                               ▼
            ┌──────────────────────────────┐
            │ Insert into products table   │
            │ (images array included)      │
            └──────────────┬───────────────┘
                           │
                           ▼
        ┌──────────────────────────────────┐
        │ Trigger: update_product_image_count()
        │ Fires BEFORE INSERT                │
        │ ├─ NEW.image_count = 2             │
        │ └─ NEW.primary_image = url1        │
        └──────────────┬────────────────────┘
                       │
                       ▼
        ┌──────────────────────────────────┐
        │ Row saved with:                  │
        │ - id: uuid (generated)           │
        │ - images: [url1, url2]           │
        │ - image_count: 2 (calculated)    │
        │ - primary_image: url1 (set)      │
        └──────────────┬────────────────────┘
                       │
         ┌─────────────┴─────────────┐
         │ sku_variants array has    │
         │ items? (> 0)              │
         │                           │
    NO  │    YES
        ▼      ▼
    Skip   Loop through
    SKU    sku_variants
    Insert │
           ▼
    ┌──────────────────────────────┐
    │ For each SKU variant:        │
    │ Build SKU object:            │
    │ {                            │
    │  product_id: product.id,     │
    │  unit_type: "Litre",         │
    │  quantity: "500ml",          │
    │  pieces_per_box: 6,          │
    │  unit_price: 150,            │
    │  unit_mrp: 200,              │
    │  box_price: 900,             │
    │  box_mrp: 1200               │
    │ }                            │
    └──────────────┬───────────────┘
                   │
                   ▼
    ┌──────────────────────────────┐
    │ Insert into product_skus     │
    │ with product_id FK           │
    └──────────────┬───────────────┘
                   │
         ┌─────────┴─────────┐
         │ More variants?    │
         │                   │
    YES  │    NO
        │      ▼
        └─→ All SKUs inserted
              │
              ▼
    ┌──────────────────────────────┐
    │ Return created product       │
    │ (without skus in response)   │
    └──────────────┬───────────────┘
                   │
                   ▼ (Network)
        ┌──────────────────────────┐
        │ Frontend receives:       │
        │ {                        │
        │  success: true,          │
        │  data: {                 │
        │    product: {            │
        │      id: "uuid",         │
        │      product_id: "...",  │
        │      ...                 │
        │    }                     │
        │  }                       │
        │ }                        │
        └──────────────┬───────────┘
                       │
                       ▼
            ┌──────────────────────┐
            │ Show Success Message │
            │ Redirect to Products │
            └──────────────────────┘
                       │
                       ▼
                    SUCCESS
                      END
```

---

## 3. Get Product with SKUs Flow

```
START
  │
  ▼
┌─────────────────────────────────────┐
│ Frontend: GET /api/products/{id}    │
└──────────────┬──────────────────────┘
               │
               ▼
┌─────────────────────────────────────┐
│ Server Route: GET /:id              │
│ (server/routes/products.ts)         │
└──────────────┬──────────────────────┘
               │
               ▼
┌─────────────────────────────────────────────────────────┐
│ Supabase Query:                                         │
│ .from("products")                                       │
│ .select(                                                │
│   "*, category:categories(*),                           │
│    variants:product_variants(*),                        │
│    skus:product_skus(*)"                                │
│ )                                                       │
│ .eq("id", id)                                           │
│ .single()                                               │
└──────────────┬──────────────────────────────────────────┘
               │
        ┌──────┴──────────────┐
        │                     │
        ▼                     ▼
    ┌─────────────┐    ┌──────────────────┐
    │ FROM        │    │ JOIN product_skus│
    │ products p  │    │ WHERE            │
    │ WHERE       │    │ product_id = id  │
    │ p.id = id   │    │                  │
    └──────┬──────┘    └────────┬─────────┘
           │                    │
           ▼                    ▼
    ┌────────────────────────────────────┐
    │ Result Set:                        │
    │ ┌──────────────────────────────┐  │
    │ │ PRODUCT ROW                  │  │
    │ ├──────────────────────────────┤  │
    │ │ id: "abc123"                 │  │
    │ │ product_id: "PROD-001"       │  │
    │ │ title: "Mustard Oil"         │  │
    │ │ images: [url1, url2]         │  │
    │ │ image_count: 2               │  │
    │ │ primary_image: url1          │  │
    │ │ price: 200                   │  │
    │ │ mrp: 350                     │  │
    │ │ ...other fields...           │  │
    │ └──────────────────────────────┘  │
    │                                    │
    │ ┌──────────────────────────────┐  │
    │ │ SKUs ARRAY (skus property)   │  │
    │ ├──────────────────────────────┤  │
    │ │ [                            │  │
    │ │   {                          │  │
    │ │     id: "sku1",              │  │
    │ │     product_id: "abc123",    │  │
    │ │     unit_type: "Litre",      │  │
    │ │     quantity: "500ml",       │  │
    │ │     pieces_per_box: 6,       │  │
    │ │     unit_price: 150,         │  │
    │ │     unit_mrp: 200,           │  │
    │ │     box_price: 900,          │  │
    │ │     box_mrp: 1200            │  │
    │ │   },                         │  │
    │ │   {                          │  │
    │ │     id: "sku2",              │  │
    │ │     product_id: "abc123",    │  │
    │ │     unit_type: "Litre",      │  │
    │ │     quantity: "1L",          │  │
    │ │     pieces_per_box: 6,       │  │
    │ │     unit_price: 280,         │  │
    │ │     unit_mrp: 350,           │  │
    │ │     box_price: 1680,         │  │
    │ │     box_mrp: 2100            │  │
    │ │   }                          │  │
    │ │ ]                            │  │
    │ └──────────────────────────────┘  │
    │                                    │
    │ ┌──────────────────────────────┐  │
    │ │ CATEGORY (nested relation)   │  │
    │ ├──────────────────────────────┤  │
    │ │ id: "cat1"                   │  │
    │ │ name: "Oils"                 │  │
    │ └──────────────────────────────┘  │
    └────────────────────────────────────┘
         │
         ▼
    ┌──────────────────────────────────┐
    │ Normalize Product Row            │
    │ (normalizeProductRow function)   │
    │ - Format images                  │
    │ - Ensure consistency             │
    │ - Handle null values             │
    └──────────────┬───────────────────┘
         │
         ▼
    ┌──────────────────────────────────┐
    │ Return API Response              │
    │ {                                │
    │   success: true,                 │
    │   data: {                        │
    │     product: {                   │
    │       id: "abc123",              │
    │       product_id: "PROD-001",    │
    │       title: "Mustard Oil",      │
    │       images: [...],             │
    │       image_count: 2,            │
    │       primary_image: url1,       │
    │       skus: [                    │
    │         {                        │
    │           unit_type: "Litre",    │
    │           quantity: "500ml",     │
    │           unit_price: 150,       │
    │           box_price: 900         │
    │         },                       │
    │         {...}                    │
    │       ]                          │
    │     }                            │
    │   }                              │
    │ }                                │
    └──────────────┬───────────────────┘
         │
         ▼ (Network)
    ┌──────────────────────────────────┐
    │ Frontend receives data           │
    │ Product ready to display         │
    │ SKUs ready for variant selector  │
    │ Images ready for gallery         │
    └──────────────┬───────────────────┘
         │
         ▼
    ┌──────────────────────────────────┐
    │ Render ProductDetail Page:       │
    │ - Show title, price, images      │
    │ - Display image gallery          │
    │ - Show SKU selector              │
    │ - Display variant prices         │
    │ - Add to cart button             │
    └──────────────┬───────────────────┘
         │
         ▼
      SUCCESS
        END
```

---

## 4. Image Trigger Execution

```
Data Insertion/Update
        │
        ▼
┌─────────────────────────┐
│ INSERT/UPDATE products  │
│ SET images = [url1,url2]│
└──────────┬──────────────┘
           │
           ▼
┌──────────────────────────────────────────────┐
│ Trigger: trigger_update_product_image_count  │
│ BEFORE INSERT OR UPDATE OF images            │
│ FOR EACH ROW                                 │
└──────────┬───────────────────────────────────┘
           │
           ▼
┌──────────────────────────────────────────────┐
│ Function: update_product_image_count()       │
│                                              │
│ BEGIN                                        │
│   -- Step 1: Calculate image count           │
│   NEW.image_count :=                         │
│     COALESCE(array_length(NEW.images, 1), 0)│
│   │                                          │
│   │ If images = [url1, url2]                 │
│   │ → image_count = 2                        │
│   │                                          │
│   │ If images = NULL or []                   │
│   │ → image_count = 0                        │
│   │                                          │
│   ▼                                          │
│   -- Step 2: Set primary image               │
│   NEW.primary_image :=                       │
│     COALESCE(NEW.images[1], NULL)            │
│   │                                          │
│   │ If images[1] exists                      │
│   │ → primary_image = url1                   │
│   │                                          │
│   │ If images is empty                       │
│   │ → primary_image = NULL                   │
│   │                                          │
│   ▼                                          │
│   -- Step 3: Return modified row             │
│   RETURN NEW;                                │
│ END;                                         │
└──────────┬───────────────────────────────────┘
           │
           ▼
┌──────────────────────────────────────────────┐
│ Row Ready for INSERT/UPDATE                  │
│ - image_count calculated                     │
│ - primary_image set                          │
│ - All other fields unchanged                 │
└──────────┬───────────────────────────────────┘
           │
           ▼
┌──────────────────────────────────────────────┐
│ INSERT/UPDATE completes                      │
│ Row saved to products table with:            │
│ - images: [url1, url2]                       │
│ - image_count: 2                             │
│ - primary_image: url1                        │
│ - all other product fields                   │
└──────────┬───────────────────────────────────┘
           │
           ▼
     SUCCESS
```

---

## 5. Database Relationships

```
┌──────────────────┐
│     PRODUCTS     │
├──────────────────┤
│ id (PK)          │◄────────┐
│ product_id (U)   │         │
│ title            │         │
│ price, mrp       │         │
│ images (TEXT[])  │         │
│ image_count      │         │ ONE
│ primary_image    │         │ TO
│ ...              │         │
└──────────────────┘         │ MANY
         ▲                    │
         │                    │
         │ (FK)               │
         │ ON DELETE          │
         │ CASCADE            │
         │                    │
┌────────┴──────────────────────────┐
│     PRODUCT_SKUS                   │
├────────────────────────────────────┤
│ id (PK)                            │
│ product_id (FK)                    │
│ unit_type (Litre | Kg) [CHK]       │
│ quantity (500ml, 1L, etc)          │
│ pieces_per_box (6|8|10|12) [CHK]   │
│ unit_price, unit_mrp               │
│ box_price, box_mrp                 │
│ created_at, updated_at             │
└────────────────────────────────────┘

Relationship:
- 1 Product → ∞ SKU Variants
- When Product deleted → SKU Variants auto-deleted (CASCADE)
- Each SKU variant belongs to exactly 1 product
```

---

## 6. Request/Response Cycle

```
Frontend (React Component)
    │
    │ User fills form & clicks "Create"
    │
    ▼
Prepare Payload:
{
  product_id: "PROD-001",
  title: "Oil",
  price: 200,
  mrp: 350,
  images: ["https://..."],
  sku_variants: [
    {
      unitType: "Litre",
      quantity: "500ml",
      piecesPerBox: 6,
      price: 150,
      mrp: 200,
      boxPrice: 900,
      boxMrp: 1200
    }
  ]
}
    │
    ▼
POST /api/admin/products
(Network Request)
    │
    ▼
Express Router:
  server/routes/admin/products.ts
  POST / handler
    │
    ▼
Calls: adminCreateProduct(req.body)
    │
    ▼
adminCreateProduct():
  1. Destructure: { sku_variants, ...productData }
  2. supabase.from("products").insert(productData)
       ├─ image_count trigger fires
       ├─ primary_image trigger fires
       └─ → product inserted
  3. Map SKU fields: unitType → unit_type
  4. supabase.from("product_skus").insert(skusArray)
       └─ → skus inserted (linked via product_id)
  5. return product
    │
    ▼
Database:
  INSERT products (image_count, primary_image auto-calc)
  INSERT product_skus (with product_id FK)
    │
    ▼
Return Response:
{
  success: true,
  data: {
    product: {
      id: "uuid",
      product_id: "PROD-001",
      ...
    }
  }
}
    │
    ▼
Frontend:
  Handle response
  Show success message
  Redirect to products list
    │
    ▼
User sees new product in list
```

---

## 7. SKU Variant Pricing Calculation

```
User Input:
┌────────────────────────┐
│ Unit Type: Litre       │
│ Quantity: 500ml        │
│ Pieces per Box: 6      │
│ Unit Price: 150        │ ← User enters
│ Unit MRP: 200          │ ← User enters
└────────────────────────┘
        │
        ▼
Frontend Auto-Calculate:
┌────────────────────────┐
│ Box Price:             │
│ = Unit Price × Pieces  │
│ = 150 × 6              │
│ = 900                  │ ← Auto-filled
│                        │
│ Box MRP:               │
│ = Unit MRP × Pieces    │
│ = 200 × 6              │
│ = 1200                 │ ← Auto-filled
└────────────────────────┘
        │
        ▼
Form Display:
┌────────────────────────┐
│ Unit Price: 150        │
│ Unit MRP: 200          │
│ Box Price: 900         │
│ Box MRP: 1200          │
└────────────────────────┘
        │
        ▼
Backend Receives:
{
  unitType: "Litre",
  quantity: "500ml",
  piecesPerBox: 6,
  price: 150,
  mrp: 200,
  boxPrice: 900,
  boxMrp: 1200
}
        │
        ▼
Mapped to Database Fields:
{
  unit_type: "Litre",
  quantity: "500ml",
  pieces_per_box: 6,
  unit_price: 150,
  unit_mrp: 200,
  box_price: 900,
  box_mrp: 1200
}
        │
        ▼
Stored in product_skus Table
```

This diagram shows how the system handles everything from data input through calculation and storage!
